export const i18nConfig = {
  locales: ['en', 'pt', 'es'],
  defaultLocale: 'en',
}
