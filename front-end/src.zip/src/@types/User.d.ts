type User = {
  id: string
  name: string
  username: string
  email: string
  phone: string
  picture: string
  country: string
  state: string
  city: string
  birthDate: string
}
